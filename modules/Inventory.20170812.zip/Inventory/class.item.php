<?php

/** 
 *	This module is for doing a stock taking (aka inventory).
 */

/**************************************************************
 *
 *	This module allows an employee to do a partial stock taking
 *
 **************************************************************/

/*************************************************************************//**
 *
 *	Class Inventory is the routines for doing a stock taking.
 *
 *	Class Inventory is the routines for doing a stock taking.
 *	It also allows you to do inventory transfers of ALL inventory
 *	without having to count those items at both locations.  
 *	ASSUMPTION is that you will do an appropriate inventory count later.
 *
 * ***************************************************************************/
class item extends 
{
	var $location;		//!< Inventory location
	var $barcode;
	var $document_date;
	var $title;
	var $stock_id;
	var $description;
	var $debug;
	var $qoh;
	/********************************************************************************//**
	 * Constructor
	 *
	 * @param string stock_id
	 * @param string location identifier
	 * @param string date
	 * @return null
	 * *********************************************************************************/
	/*@void@*/function __construct( $stock_id, $location = -1, $date = null  )
	{
		$this->stock_id = $stock_id;
		if( $location == -1 )
		{
			//need to look up the default location
		}
		else 
		{
			//Need to validate that the location value is valid
			$this->location = $location;
		}
		if( null == $date )
		{
			$this->document_date = date( 'Y-m-d' );
		}
		else
			$this->document_date = $date;
		return;
	}
	/********************************************************************************//**
	 * Is the item in the ?stock_master? databas
	 *
	 * @param string the stock_id to check
	 * @return bool Is the item in the ?stock_master? database
	 * *********************************************************************************/
	/*@bool@*/function isStockid( $stock_id )
	{
		include_once( $this->path_to_root . "/includes/db/inventory_db.inc" );
		return is_inventory_item( $stock_id );
	}
	/********************************************************************************//**
	 * check for a foreign/part code.  Sets stock_id if found.
	 *
	 * @param string stock_id/item_code
	 * @returns bool whether item is in item_codes AND stock_id<>item_code
	 * *********************************************************************************/
	/*@bool@*/ function isItemCode( $item_code )
	{
		//Is the code in the Item_code table AND is NOT the native master code
        	$sql = "SELECT stock_id FROM "
        	        //. $this->tb_pref ."item_codes "
        	        . TB_PREF ."item_codes "
        	        . " WHERE item_code=".db_escape($item_code)."
        	                AND stock_id!=".db_escape($item_code);
        	$res = db_query($sql, "where used query failed");
		$fet = db_fetch_assoc( $res );
		if( count( $fet ) > 0  )
		{
			if( $this->debug > 1 )
			{
				echo __FILE__ . ":" . __LINE__ . " DEBUG: isItemCode count > 0<br />";
				$this->stock_id = $ret['stock_id'];
			}
			//should we set the data into a set of variables?
			return TRUE;
		}
		return FALSE;
	}
	/********************************************************************************//**
	 * retrieve item's description.  Depends on stock_id being set
	 *
	 * @returns bool whether we retrieved or not.
	 * *********************************************************************************/
	/*@bool@*/function get_item_description()
	{
		if( !isset( $this->stock_id ) )
			return FALSE;
		//Using stock_id get the description

 		$item_row = get_item($this->stock_id);	//includes/db/inventory_db.inc
                if ($item_row == null)
		{
			display_error("invalid item : $stock_id", "");
		}
		else if( strlen($item_row["description"]) > 1)
		{
			$this->description = $item_row["description"];
			return TRUE;
		}
		return FALSE;
	}
	/********************************************************************************//**
	 * retrieve item's QOH on a date.  Depends on stock_id, location, document_date being set
	 *
	 * @returns bool whether we retrieved or not.
	 * *********************************************************************************/
	/*@bool@*/function get_item_qoh_location( $stock_id )
	{
		if( !isset( $this->stock_id ) )
			return FALSE;
		if( !isset( $this->location ) )
			return FALSE;
		if( !isset( $this->document_date ) )
			return FALSE;
                // collect quantities by stock_id
		$this->qoh = get_qoh_on_date( $this->stock_id, $this->location, $this->document_date);	//includes/db/inventory_db.inc
		return TRUE;
	}
}
?>
