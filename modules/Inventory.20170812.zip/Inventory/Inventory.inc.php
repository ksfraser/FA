<?php
/**********************************************
Name: Inventory 
Free software under GNU GPL
***********************************************/

define( "Inventory_prefsDB", "Inventory_prefs" );

?>
