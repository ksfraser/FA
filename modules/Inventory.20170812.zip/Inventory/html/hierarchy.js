var hierarchy =
[
    [ "db_base", "classdb__base.html", [
      [ "generic_interface", "classgeneric__interface.html", null ],
      [ "generic_orders", "classgeneric__orders.html", null ]
    ] ],
    [ "hooks", null, [
      [ "hooks_Inventory", "classhooks___inventory.html", null ]
    ] ]
];