var _inventory_8php =
[
    [ "$db", "_inventory_8php.html#a907d78797a1b764e913b0c565a5097b0", null ],
    [ "$debug_sql", "_inventory_8php.html#a6728601dcaf0009055cd4b1820fd320e", null ],
    [ "$found", "_inventory_8php.html#a19655ecca257a134034e17d5bedc0f75", null ],
    [ "$Inventoryc", "_inventory_8php.html#ac699461de9f08f2d3c3fe8e98c3915c0", null ],
    [ "$page_security", "_inventory_8php.html#a6a2eb6d6d1862e1894292ba8e3db0921", null ],
    [ "$path_to_root", "_inventory_8php.html#aa06340db3c59508641d32c142ce47334", null ],
    [ "$prefsDB", "_inventory_8php.html#a6cf1b15a97568741fc1eac559d60cf71", null ]
];