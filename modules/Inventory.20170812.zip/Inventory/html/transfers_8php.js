var transfers_8php =
[
    [ "check_item_data", "transfers_8php.html#a105b5ebe678a9d8341b470bfd27da3fb", null ],
    [ "handle_delete_item", "transfers_8php.html#ad6e11a922100a5537b8a6af67d9066c5", null ],
    [ "handle_new_item", "transfers_8php.html#a81ab4fe931a16539611215eaf72e66a2", null ],
    [ "handle_new_order", "transfers_8php.html#ad8d821d935ca4889b4b6725f97c2432c", null ],
    [ "handle_update_item", "transfers_8php.html#a235a1a2486f6d62e2ddd2b9e090c629f", null ],
    [ "line_start_focus", "transfers_8php.html#a2c77e2f046b94784555c202d2d014430", null ],
    [ "$id", "transfers_8php.html#ae97941710d863131c700f069b109991e", null ],
    [ "$js", "transfers_8php.html#a747181e96d083c6396169e81e4d2056d", null ],
    [ "$page_security", "transfers_8php.html#a6a2eb6d6d1862e1894292ba8e3db0921", null ],
    [ "$path_to_root", "transfers_8php.html#aa06340db3c59508641d32c142ce47334", null ]
];