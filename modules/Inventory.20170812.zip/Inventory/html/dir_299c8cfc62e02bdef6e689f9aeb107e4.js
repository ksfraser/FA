var dir_299c8cfc62e02bdef6e689f9aeb107e4 =
[
    [ "lang", "dir_61ad0ec5d3382189deea7af8b58acd97.html", "dir_61ad0ec5d3382189deea7af8b58acd97" ],
    [ "class.generic_interface.php", "class_8generic__interface_8php.html", [
      [ "generic_interface", "classgeneric__interface.html", "classgeneric__interface" ]
    ] ],
    [ "class.generic_orders.php", "class_8generic__orders_8php.html", [
      [ "generic_orders", "classgeneric__orders.html", "classgeneric__orders" ]
    ] ],
    [ "class.Inventory.php", "class_8_inventory_8php.html", "class_8_inventory_8php" ],
    [ "db_base.php", "db__base_8php.html", "db__base_8php" ],
    [ "hooks.php", "hooks_8php.html", "hooks_8php" ],
    [ "Inventory.php", "_inventory_8php.html", "_inventory_8php" ],
    [ "inventory_entry.php", "inventory__entry_8php.html", "inventory__entry_8php" ],
    [ "transfers.php", "transfers_8php.html", "transfers_8php" ]
];