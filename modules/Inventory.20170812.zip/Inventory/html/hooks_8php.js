var hooks_8php =
[
    [ "hooks_Inventory", "classhooks___inventory.html", "classhooks___inventory" ],
    [ "SS_Inventory", "hooks_8php.html#a1fb768bb003f5655c098959ea6cb4a93", null ]
];