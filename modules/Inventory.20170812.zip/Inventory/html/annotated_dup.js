var annotated_dup =
[
    [ "db_base", "classdb__base.html", "classdb__base" ],
    [ "generic_interface", "classgeneric__interface.html", "classgeneric__interface" ],
    [ "generic_orders", "classgeneric__orders.html", "classgeneric__orders" ],
    [ "hooks_Inventory", "classhooks___inventory.html", "classhooks___inventory" ]
];