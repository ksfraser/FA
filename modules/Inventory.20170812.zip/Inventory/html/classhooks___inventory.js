var classhooks___inventory =
[
    [ "install_access", "classhooks___inventory.html#abf53ee4d03fe1c83a522721f682e0ef9", null ],
    [ "install_options", "classhooks___inventory.html#ab5176986555717d3f1048c5c94e9fd4e", null ],
    [ "$module_name", "classhooks___inventory.html#a68b641f7e74c6ab83515f2428072637d", null ]
];