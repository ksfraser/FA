var classgeneric__interface =
[
    [ "__construct", "classgeneric__interface.html#ac52c61283389d805af20b9bbe04666da", null ],
    [ "append_file", "classgeneric__interface.html#ae414ba97737024d15ab0f15a3e716736", null ],
    [ "base_page", "classgeneric__interface.html#abc78f04efca27ac094bca2af729a7a9c", null ],
    [ "close_file", "classgeneric__interface.html#a461174d1cee0f5e9039638ba0fdbd5c3", null ],
    [ "display", "classgeneric__interface.html#a0b9b6e6acd4a839fc7c2f26f96b5cfa8", null ],
    [ "overwrite_file", "classgeneric__interface.html#a1612254cc1c064509235a787516cb786", null ],
    [ "related_tabs", "classgeneric__interface.html#a7a9f62c16ca87f7e3870e8b355e74d9f", null ],
    [ "run", "classgeneric__interface.html#afb0fafe7e02a3ae1993c01c19fad2bae", null ],
    [ "show_form", "classgeneric__interface.html#a42a14cc0f37ae20600078a9e1ad9301a", null ],
    [ "$errors", "classgeneric__interface.html#ab24faf4aa647cdcee494fc48524ad4ff", null ],
    [ "$help_context", "classgeneric__interface.html#a832c456a7388db586e846e92944ab5cf", null ],
    [ "$javascript", "classgeneric__interface.html#a687855b3cefd1fc1232e0f457ff7e41b", null ],
    [ "$page_title", "classgeneric__interface.html#ace7d5ca2414fbd4f411985155fe2f643", null ]
];