var classdb__base =
[
    [ "__construct", "classdb__base.html#a389899a99eb66a5d569efc75c5daad2d", null ],
    [ "create_prefs_tablename", "classdb__base.html#aa5a6297eb46ec1cb95191a576056263b", null ],
    [ "get_pref", "classdb__base.html#a3ff0b2d6e78e996cd0603bd146655bcb", null ],
    [ "get_var", "classdb__base.html#a941a46bb4281e9cba813055736af135c", null ],
    [ "is_installed", "classdb__base.html#a740de315cce4796d58d64f5ccd2984ce", null ],
    [ "loadprefs", "classdb__base.html#a17a818d412b66beb838bcbe9d37dea61", null ],
    [ "set_pref", "classdb__base.html#af757c2c443468f1bfdd7d8409add0ecb", null ],
    [ "set_prefix", "classdb__base.html#aa410349e1483c0c27a70d97fe0e4e72f", null ],
    [ "set_var", "classdb__base.html#acd5cc0cb88ad605f5372b3222a6b0f2f", null ],
    [ "updateprefs", "classdb__base.html#ad4c8dd329fefe14e53b7426d47905f9e", null ],
    [ "$action", "classdb__base.html#aa698a3e72116e8e778be0e95d908ee30", null ],
    [ "$company_prefix", "classdb__base.html#a72db27a2e905fac1bd6b79164ce21051", null ],
    [ "$config_values", "classdb__base.html#ae9fca893fa073428bff0d54edfb225b2", null ],
    [ "$db_connection", "classdb__base.html#af908e1ef16f0db5f47519cb83b633e96", null ],
    [ "$dbHost", "classdb__base.html#ad0ddb2725e69c88a729e0cc242a1b2a6", null ],
    [ "$dbName", "classdb__base.html#a68f39949e76b64662a06cb56579d91c3", null ],
    [ "$dbPassword", "classdb__base.html#a21bc2efa4855a9484c564803d4569a19", null ],
    [ "$dbUser", "classdb__base.html#a4a92606de85aafdc0dcae4976b7ca669", null ],
    [ "$prefs_tablename", "classdb__base.html#ab0fd4f3b2a3c1cb7b398a8c52bb97d40", null ]
];