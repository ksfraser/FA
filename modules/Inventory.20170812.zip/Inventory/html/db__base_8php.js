var db__base_8php =
[
    [ "db_base", "classdb__base.html", "classdb__base" ],
    [ "$path_to_root", "db__base_8php.html#aa06340db3c59508641d32c142ce47334", null ]
];