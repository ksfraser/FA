var searchData=
[
  ['db_5fbase',['db_base',['../classdb__base.html',1,'']]]
];
