var searchData=
[
  ['upc_5ftable',['upc_table',['../class_inventory.html#ace05d09d14b409647be0aead6faa8310',1,'Inventory']]],
  ['updateprefs',['updateprefs',['../classgeneric__orders.html#ad4c8dd329fefe14e53b7426d47905f9e',1,'generic_orders\updateprefs()'],['../classdb__base.html#ad4c8dd329fefe14e53b7426d47905f9e',1,'db_base\updateprefs()']]]
];
