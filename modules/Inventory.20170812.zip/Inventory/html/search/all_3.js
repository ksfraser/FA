var searchData=
[
  ['base_5fpage',['base_page',['../classgeneric__interface.html#abc78f04efca27ac094bca2af729a7a9c',1,'generic_interface\base_page()'],['../classgeneric__orders.html#abc78f04efca27ac094bca2af729a7a9c',1,'generic_orders\base_page()']]]
];
