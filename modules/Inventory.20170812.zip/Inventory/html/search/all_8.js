var searchData=
[
  ['generic_5finterface',['generic_interface',['../classgeneric__interface.html',1,'']]],
  ['generic_5forders',['generic_orders',['../classgeneric__orders.html',1,'']]],
  ['get_5fid_5frange',['get_id_range',['../classgeneric__orders.html#a07553ec39788acacdb97a070f374da6c',1,'generic_orders']]],
  ['get_5fpref',['get_pref',['../classdb__base.html#a3ff0b2d6e78e996cd0603bd146655bcb',1,'db_base']]],
  ['get_5fpurchase_5forder',['get_purchase_order',['../classgeneric__orders.html#ad3564fce0fc62f0a70c0f0d63c8bcce5',1,'generic_orders']]],
  ['get_5fsupplier_5forder',['get_supplier_order',['../classgeneric__orders.html#a74464f655bf2867dfec6a9824f485791',1,'generic_orders']]],
  ['get_5fvar',['get_var',['../classdb__base.html#a941a46bb4281e9cba813055736af135c',1,'db_base']]]
];
