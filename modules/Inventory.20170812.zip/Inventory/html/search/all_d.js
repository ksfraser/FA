var searchData=
[
  ['related_5ftabs',['related_tabs',['../classgeneric__interface.html#a7a9f62c16ca87f7e3870e8b355e74d9f',1,'generic_interface\related_tabs()'],['../classgeneric__orders.html#a7a9f62c16ca87f7e3870e8b355e74d9f',1,'generic_orders\related_tabs()']]],
  ['run',['run',['../classgeneric__interface.html#afb0fafe7e02a3ae1993c01c19fad2bae',1,'generic_interface\run()'],['../classgeneric__orders.html#afb0fafe7e02a3ae1993c01c19fad2bae',1,'generic_orders\run()']]]
];
