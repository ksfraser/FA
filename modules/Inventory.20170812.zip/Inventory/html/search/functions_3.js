var searchData=
[
  ['can_5fprocess',['can_process',['../inventory__entry_8php.html#a63f4639380e00580a10d38c0422033d3',1,'inventory_entry.php']]],
  ['check_5fitem_5fdata',['check_item_data',['../inventory__entry_8php.html#a266888ca810bc02fdbef7ddc2a513f0f',1,'check_item_data():&#160;inventory_entry.php'],['../transfers_8php.html#a105b5ebe678a9d8341b470bfd27da3fb',1,'check_item_data():&#160;transfers.php']]],
  ['checkprefs',['checkprefs',['../classgeneric__orders.html#a05a9b792f4ef575a4ec15edb2826080d',1,'generic_orders']]],
  ['close_5ffile',['close_file',['../classgeneric__interface.html#a461174d1cee0f5e9039638ba0fdbd5c3',1,'generic_interface']]],
  ['copy_5ffrom_5fcart',['copy_from_cart',['../inventory__entry_8php.html#a80fb9d4f2b45fd8234b36e8804d8ac1e',1,'inventory_entry.php']]],
  ['copy_5fto_5fcart',['copy_to_cart',['../inventory__entry_8php.html#a76aeda12eb3f75b873a4fd01001280ec',1,'inventory_entry.php']]],
  ['create_5fcart',['create_cart',['../inventory__entry_8php.html#ad03789f4ca0eb9dec4959d08b92af629',1,'inventory_entry.php']]],
  ['create_5fprefs_5ftablename',['create_prefs_tablename',['../classdb__base.html#aa5a6297eb46ec1cb95191a576056263b',1,'db_base']]]
];
