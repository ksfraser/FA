var searchData=
[
  ['db_5fbase',['db_base',['../classdb__base.html',1,'']]],
  ['db_5fbase_2ephp',['db_base.php',['../db__base_8php.html',1,'']]],
  ['display',['display',['../classgeneric__interface.html#a0b9b6e6acd4a839fc7c2f26f96b5cfa8',1,'generic_interface\display()'],['../classgeneric__orders.html#a0b9b6e6acd4a839fc7c2f26f96b5cfa8',1,'generic_orders\display()']]]
];
