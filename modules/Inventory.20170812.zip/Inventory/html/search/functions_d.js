var searchData=
[
  ['set_5fpref',['set_pref',['../classdb__base.html#af757c2c443468f1bfdd7d8409add0ecb',1,'db_base']]],
  ['set_5fprefix',['set_prefix',['../classdb__base.html#aa410349e1483c0c27a70d97fe0e4e72f',1,'db_base']]],
  ['set_5fvar',['set_var',['../classdb__base.html#acd5cc0cb88ad605f5372b3222a6b0f2f',1,'db_base']]],
  ['show_5fform',['show_form',['../classgeneric__interface.html#a42a14cc0f37ae20600078a9e1ad9301a',1,'generic_interface\show_form()'],['../classgeneric__orders.html#a42a14cc0f37ae20600078a9e1ad9301a',1,'generic_orders\show_form()']]]
];
