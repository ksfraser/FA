var searchData=
[
  ['generic_5finterface',['generic_interface',['../classgeneric__interface.html',1,'']]],
  ['generic_5forders',['generic_orders',['../classgeneric__orders.html',1,'']]]
];
