var searchData=
[
  ['write',['write',['../class_inventory.html#aa245791a86f0178986f84c9357339aab',1,'Inventory']]]
];
