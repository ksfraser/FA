var searchData=
[
  ['set_5fpref',['set_pref',['../classdb__base.html#af757c2c443468f1bfdd7d8409add0ecb',1,'db_base']]],
  ['set_5fprefix',['set_prefix',['../classdb__base.html#aa410349e1483c0c27a70d97fe0e4e72f',1,'db_base']]],
  ['set_5fvar',['set_var',['../classdb__base.html#acd5cc0cb88ad605f5372b3222a6b0f2f',1,'db_base']]],
  ['show_5fform',['show_form',['../classgeneric__interface.html#a42a14cc0f37ae20600078a9e1ad9301a',1,'generic_interface\show_form()'],['../classgeneric__orders.html#a42a14cc0f37ae20600078a9e1ad9301a',1,'generic_orders\show_form()']]],
  ['ss_5finventory',['SS_Inventory',['../hooks_8php.html#a1fb768bb003f5655c098959ea6cb4a93',1,'hooks.php']]],
  ['st_5finventory',['ST_INVENTORY',['../class_8_inventory_8php.html#a77d10fba02c0dd107b20f62ef1ca564f',1,'ST_INVENTORY():&#160;class.Inventory.php'],['../class_8_inventory_8php.html#a95f64f33c0a439e6cceef0a7868b3c88',1,'ST_Inventory():&#160;class.Inventory.php']]]
];
