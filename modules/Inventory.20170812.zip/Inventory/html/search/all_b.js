var searchData=
[
  ['line_5fstart_5ffocus',['line_start_focus',['../inventory__entry_8php.html#a9c78c96b435f3cd439b4de2de3e97ed1',1,'line_start_focus():&#160;inventory_entry.php'],['../transfers_8php.html#a2c77e2f046b94784555c202d2d014430',1,'line_start_focus():&#160;transfers.php']]],
  ['loadprefs',['loadprefs',['../classgeneric__orders.html#a17a818d412b66beb838bcbe9d37dea61',1,'generic_orders\loadprefs()'],['../classdb__base.html#a17a818d412b66beb838bcbe9d37dea61',1,'db_base\loadprefs()']]]
];
