var searchData=
[
  ['display',['display',['../classgeneric__interface.html#a0b9b6e6acd4a839fc7c2f26f96b5cfa8',1,'generic_interface\display()'],['../classgeneric__orders.html#a0b9b6e6acd4a839fc7c2f26f96b5cfa8',1,'generic_orders\display()']]]
];
