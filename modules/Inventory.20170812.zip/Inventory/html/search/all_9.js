var searchData=
[
  ['handle_5fcancel_5forder',['handle_cancel_order',['../inventory__entry_8php.html#aa3be67e52a3463449db26bc5bcf5ef41',1,'inventory_entry.php']]],
  ['handle_5fdelete_5fitem',['handle_delete_item',['../inventory__entry_8php.html#ae88839c533e54247386e34ec3728ceee',1,'handle_delete_item($line_no):&#160;inventory_entry.php'],['../transfers_8php.html#ad6e11a922100a5537b8a6af67d9066c5',1,'handle_delete_item($id):&#160;transfers.php']]],
  ['handle_5fnew_5fitem',['handle_new_item',['../inventory__entry_8php.html#a81ab4fe931a16539611215eaf72e66a2',1,'handle_new_item():&#160;inventory_entry.php'],['../transfers_8php.html#a81ab4fe931a16539611215eaf72e66a2',1,'handle_new_item():&#160;transfers.php']]],
  ['handle_5fnew_5forder',['handle_new_order',['../transfers_8php.html#ad8d821d935ca4889b4b6725f97c2432c',1,'transfers.php']]],
  ['handle_5fupdate_5fitem',['handle_update_item',['../inventory__entry_8php.html#a235a1a2486f6d62e2ddd2b9e090c629f',1,'handle_update_item():&#160;inventory_entry.php'],['../transfers_8php.html#a235a1a2486f6d62e2ddd2b9e090c629f',1,'handle_update_item():&#160;transfers.php']]],
  ['hooks_2ephp',['hooks.php',['../hooks_8php.html',1,'']]],
  ['hooks_5finventory',['hooks_Inventory',['../classhooks___inventory.html',1,'']]]
];
