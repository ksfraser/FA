var searchData=
[
  ['action_5fshow_5fform',['action_show_form',['../classgeneric__orders.html#a691cb117e08ecd63f896d6164fef143a',1,'generic_orders']]],
  ['append_5ffile',['append_file',['../classgeneric__interface.html#ae414ba97737024d15ab0f15a3e716736',1,'generic_interface']]]
];
