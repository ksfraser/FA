var searchData=
[
  ['db_5fbase_2ephp',['db_base.php',['../db__base_8php.html',1,'']]]
];
