<?php

define('API_ROOT', realpath(__DIR__));
define('FA_ROOT', realpath(API_ROOT . '/../..'));

