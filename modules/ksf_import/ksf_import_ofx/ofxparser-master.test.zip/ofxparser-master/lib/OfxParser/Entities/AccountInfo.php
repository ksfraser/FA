<?php

namespace OfxParser\Entities;

class AccountInfo extends AbstractEntity
{
    /**
     * @var string
     */
    public $desc;

    /**
     * @var string
     */
    public $number;
}
