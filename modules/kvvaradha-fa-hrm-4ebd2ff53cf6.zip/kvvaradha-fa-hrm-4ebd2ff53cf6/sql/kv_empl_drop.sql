DROP TABLE IF EXISTS `0_kv_empl_info`;
DROP TABLE IF EXISTS `0_kv_empl_payslip`;
